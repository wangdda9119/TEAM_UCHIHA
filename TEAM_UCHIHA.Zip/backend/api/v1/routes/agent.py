"""
React AI Agent API Routes
ReAct 패턴을 사용하는 지능형 에이전트 엔드포인트
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from loguru import logger

from backend.ai.agents.react_agent import run_react_agent

router = APIRouter()


# ============================================================================
# Request/Response Models
# ============================================================================

class AgentRequest(BaseModel):
    """에이전트 요청"""
    question: str = Field(..., description="에이전트에게 할 질문")
    max_iterations: int = Field(default=5, description="최대 반복 횟수")


class MemoryItem(BaseModel):
    """메모리 항목"""
    timestamp: str
    type: str  # "agent_step" 또는 "observation"
    iteration: int
    thought: Optional[str] = None
    action: Optional[str] = None
    action_input: Optional[str] = None
    observation: Optional[str] = None


class AgentResponse(BaseModel):
    """에이전트 응답"""
    question: str
    answer: str
    iterations: int
    status: str  # "success" 또는 "error"
    memory: Optional[List[Dict[str, Any]]] = None


class WebSearchRequest(BaseModel):
    """웹 검색 요청"""
    query: str = Field(..., description="검색 쿼리")
    max_results: int = Field(default=5, description="최대 결과 수")


class WebSearchResult(BaseModel):
    """웹 검색 결과"""
    title: str
    url: str
    content: str
    score: float


class WebSearchResponse(BaseModel):
    """웹 검색 응답"""
    query: str
    results: List[WebSearchResult]
    total_results: int
    status: str


# ============================================================================
# 1. React Agent Endpoint
# ============================================================================

@router.post("/run", response_model=AgentResponse)
async def run_agent(request: AgentRequest):
    """
    React 에이전트 실행
    
    사용 가능한 도구:
    1. web_search: 일반 웹 검색 (Tavily)
    2. hyupsung_search: 협성대학교 정보 검색
    
    Example:
        {
            "question": "협성대학교 입학 정보 알려줘",
            "max_iterations": 5
        }
    """
    try:
        logger.info(f"🤖 에이전트 요청: {request.question}")
        
        if not request.question or len(request.question.strip()) == 0:
            raise HTTPException(
                status_code=400,
                detail="질문이 비어있습니다"
            )
        
        # React Agent 실행
        answer = await run_react_agent(request.question)
        
        return AgentResponse(
            question=request.question,
            answer=answer,
            iterations=1,
            status="success",
            memory=None
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ 에이전트 실행 오류: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"에이전트 실행 실패: {str(e)}"
        )


# ============================================================================
# 2. Web Search Tool Endpoint
# ============================================================================

@router.post("/search", response_model=WebSearchResponse)
async def web_search(request: WebSearchRequest):
    """
    웹 검색 도구 (Tavily API 사용)
    
    Example:
        {
            "query": "파이썬 최신 버전",
            "max_results": 5
        }
    """
    try:
        logger.info(f"🔍 웹 검색 요청: {request.query}")
        
        if not request.query or len(request.query.strip()) == 0:
            raise HTTPException(
                status_code=400,
                detail="검색 쿼리가 비어있습니다"
            )
        
        from backend.ai.tools.search.web_search import get_tavily_tool
        
        tool = get_tavily_tool()
        results = tool.search(
            query=request.query,
            max_results=request.max_results
        )
        
        return WebSearchResponse(
            query=request.query,
            results=[
                WebSearchResult(
                    title=r["title"],
                    url=r["url"],
                    content=r["content"],
                    score=r["score"]
                )
                for r in results
            ],
            total_results=len(results),
            status="success" if results else "no_results"
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ 웹 검색 오류: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"웹 검색 실패: {str(e)}"
        )


# ============================================================================
# 3. Agent Memory Endpoint
# ============================================================================

@router.get("/memory")
async def get_agent_memory():
    """
    에이전트 메모리 조회 (Mock)
    """
    return {
        "memory_count": 0,
        "memory": [],
        "status": "success"
    }


# ============================================================================
# 4. Clear Memory Endpoint
# ============================================================================

@router.delete("/memory")
async def clear_agent_memory():
    """
    에이전트 메모리 초기화 (Mock)
    """
    return {
        "status": "success",
        "message": "메모리가 초기화되었습니다"
    }


# ============================================================================
# 5. Available Tools Endpoint
# ============================================================================

@router.get("/tools")
async def list_tools():
    """
    사용 가능한 도구 목록 조회
    
    모든 @tool 데코레이터 기반 도구를 반환합니다:
    - 기본 도구: web_search, calculator
    - 고급 도구: json_parser, text_summarizer, string_manipulator, get_current_time, list_operations
    """
    try:
        from backend.ai.tools import ALL_TOOLS
        
        tools_info = []
        for tool in ALL_TOOLS:
            tools_info.append({
                "tool_id": tool.name,
                "name": tool.name,
                "description": tool.description or "설명 없음"
            })
        
        return {
            "tools": tools_info,
            "total_tools": len(tools_info),
            "status": "success"
        }
    except Exception as e:
        logger.error(f"❌ 도구 목록 조회 오류: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"도구 목록 조회 실패: {str(e)}"
        )


# ============================================================================
# 6. Health Check Endpoint
# ============================================================================

@router.get("/health")
async def health_check():
    """
    React AI Agent 서비스 헬스 체크
    """
    try:
        from backend.ai.tools import ALL_TOOLS
        
        return {
            "status": "ok",
            "service": "React AI Agent",
            "available_tools": len(ALL_TOOLS),
            "tools": [tool.name for tool in ALL_TOOLS]
        }
    except Exception as e:
        logger.error(f"❌ 헬스 체크 오류: {str(e)}")
        return {
            "status": "error",
            "service": "React AI Agent",
            "error": str(e)
        }
