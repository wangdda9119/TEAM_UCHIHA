from .search.web_search import web_search
from .search.hyupsung_search import hyupsung_search

ALL_TOOLS = [web_search, hyupsung_search]