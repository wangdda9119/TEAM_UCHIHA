
-- Enable pgvector (already present in image, ensure extension)
CREATE EXTENSION IF NOT EXISTS vector;
